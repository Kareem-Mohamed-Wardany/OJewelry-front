"use client";
import { Button } from "@/components/ui/button";
import { ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import Anklets from "@/assets/icons/Anklets.jpg";
import Bracelets from "@/assets/icons/Bracelets.jpeg";
import Diamond from "@/assets/icons/Diamond.png";
import earings from "@/assets/icons/earings.webp";
import goldpic from "@/assets/icons/gold.png";
import neck from "@/assets/icons/neck.jpeg";
import rings from "@/assets/icons/rings.jpeg";
import sets from "@/assets/icons/sets.jpeg";
import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchAllFilteredProducts,
  fetchProductDetails,
} from "@/store/shop/products-slice";
import ShoppingProductTile from "@/components/shopping-view/product-tile";
import { addToCart, fetchCartItems } from "@/store/shop/cart-slice";
import ProductDetailsDialog from "@/components/shopping-view/product-details";
import { getFeatureImages } from "@/store/common-slice";
import Image from "next/image";
import { toast } from "react-toastify";

const categoriesWithIcon = [
  { id: "Sets", label: "Sets", icon: sets },
  { id: "Rings", label: "Rings", icon: rings },
  { id: "Necklaces_Pendants", label: "Necklaces & Pendants", icon: neck },
  { id: "Earrings", label: "Earrings", icon: earings },
  { id: "Bracelets", label: "Bracelets", icon: Bracelets },
  { id: "Anklets", label: "Anklets", icon: Anklets },
];

const brandsWithIcon = [
  { id: "Diamond", label: "Diamond", icon: Diamond },
  { id: "Gold", label: "Gold", icon: goldpic },
];
function ShoppingHome() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { productList, productDetails } = useSelector(
    (state) => state.shopProducts
  );
  const { featureImageList } = useSelector((state) => state.commonFeature);

  const [openDetailsDialog, setOpenDetailsDialog] = useState(false);

  const { user } = useSelector((state) => state.auth);

  const dispatch = useDispatch();

  function handleNavigateToListingPage(getCurrentItem, section) {
    sessionStorage.removeItem("filters");
    const currentFilter = {
      [section]: [getCurrentItem.id],
    };

    sessionStorage.setItem("filters", JSON.stringify(currentFilter));
  }

  function handleGetProductDetails(getCurrentProductId) {
    dispatch(fetchProductDetails(getCurrentProductId));
  }

  function handleAddtoCart(getCurrentProductId) {
    dispatch(
      addToCart({
        productId: getCurrentProductId,
        quantity: 1,
      })
    ).then((data) => {
      if (data?.payload?.success) {
        dispatch(fetchCartItems(user?.id));
        toast.success("Product is added to cart");
      }
    });
  }

  useEffect(() => {
    if (productDetails !== null) setOpenDetailsDialog(true);
  }, [productDetails]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % featureImageList.length);
    }, 15000);

    return () => clearInterval(timer);
  }, [featureImageList]);

  useEffect(() => {
    dispatch(
      fetchAllFilteredProducts({
        filterParams: {},
        sortParams: "price-lowtohigh",
      })
    );
  }, [dispatch]);

  console.log(productList, "productList");

  useEffect(() => {
    dispatch(getFeatureImages());
  }, [dispatch]);

  return (
    <div className="flex flex-col min-h-screen">
      <div className="relative w-full h-[600px] overflow-hidden">
        {featureImageList && featureImageList.length > 0
          ? featureImageList.map((slide, index) => (
              <img
                src={slide?.image}
                key={slide._id}
                className={`${
                  index === currentSlide ? "opacity-100" : "opacity-0"
                } absolute top-0 left-0 w-full h-full object-cover transition-opacity duration-1000`}
              />
            ))
          : null}

        {/* Conditionally render buttons only if there are more than one image */}
        {featureImageList.length > 1 && (
          <>
            <Button
              variant="outline"
              size="icon"
              onClick={() =>
                setCurrentSlide(
                  (prevSlide) =>
                    (prevSlide - 1 + featureImageList.length) %
                    featureImageList.length
                )
              }
              className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-white/80"
            >
              <ChevronLeftIcon className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() =>
                setCurrentSlide(
                  (prevSlide) => (prevSlide + 1) % featureImageList.length
                )
              }
              className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-white/80"
            >
              <ChevronRightIcon className="w-4 h-4" />
            </Button>
          </>
        )}
      </div>

      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Shop by category
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            {categoriesWithIcon.map((categoryItem) => (
              <Card
                key={categoryItem.id}
                onClick={() =>
                  handleNavigateToListingPage(categoryItem, "category")
                }
                className="cursor-pointer hover:shadow-lg transition-shadow transform hover:scale-105 flex justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/4"
              >
                <CardContent className="flex flex-col items-center justify-between p-1 bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                  <div className="flex flex-col items-center justify-center w-full mb-4">
                    <Image
                      alt={categoryItem.label}
                      src={categoryItem.icon}
                      className="w-full object-contain rounded-lg h-[30rem]"
                    />
                  </div>
                  <span className="text-xl font-semibold text-gray-700 text-center">
                    {categoryItem.label}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Shop by Brand</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {brandsWithIcon.map((brandItem) => (
              <Card
                key={brandItem.id}
                onClick={() =>
                  handleNavigateToListingPage(brandItem, "category")
                }
                className="cursor-pointer hover:shadow-lg transition-shadow transform hover:scale-105 flex justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/4"
              >
                <CardContent className="flex flex-col items-center justify-between p-1 bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">
                  <div className="flex flex-col items-center justify-center w-full mb-4">
                    <Image
                      alt={brandItem.label}
                      src={brandItem.icon}
                      className="w-full object-contain rounded-lg"
                    />
                  </div>
                  <span className="text-xl font-semibold text-gray-700 text-center">
                    {brandItem.label}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Feature Products
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {productList && productList.length > 0
              ? productList.map((productItem) => (
                  <ShoppingProductTile
                    key={productItem._id}
                    handleGetProductDetails={handleGetProductDetails}
                    product={productItem}
                    handleAddtoCart={handleAddtoCart}
                  />
                ))
              : null}
          </div>
        </div>
      </section>
      <ProductDetailsDialog
        open={openDetailsDialog}
        setOpen={setOpenDetailsDialog}
        productDetails={productDetails}
      />
    </div>
  );
}

export default ShoppingHome;
